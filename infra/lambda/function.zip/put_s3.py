import os
import boto3
from datetime import datetime
from zoneinfo import ZoneInfo

def lambda_handler(event, context):
    s3 = boto3.client("s3")
    bucket = os.environ["BUCKET_NAME"]

    now = datetime.now(ZoneInfo("America/Sao_Paulo")).strftime("%Y-%m-%dT%H-%M-%S")
    key = f"{now}.txt"

    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=f"Arquivo gerado em horário de São Paulo (BRT): {now}"
    )

    return {"file_created": key}
